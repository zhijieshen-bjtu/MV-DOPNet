Put the model trained on MatterportLayout here!
