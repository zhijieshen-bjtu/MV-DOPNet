Put the model trained on ZInd here!
