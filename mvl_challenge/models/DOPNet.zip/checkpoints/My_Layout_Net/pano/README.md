Put the model trained on PanoContext here!
