Put the model trained on Stanford2d3d here!
