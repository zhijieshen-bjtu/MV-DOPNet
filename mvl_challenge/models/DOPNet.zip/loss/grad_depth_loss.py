""" 
@Date: 2021/08/12
@description:
"""
import torch
import torch.nn as nn
import numpy as np

from ..visualization.grad import get_all


class GradDepthLoss(nn.Module):
    def __init__(self):
        super().__init__()
        self.loss = nn.L1Loss()
        self.cos = nn.CosineSimilarity(dim=-1, eps=0)

        self.grad_conv = nn.Conv1d(1, 1, kernel_size=3, stride=1, padding=0, bias=False, padding_mode='circular')
        self.grad_conv.weight = nn.Parameter(torch.tensor([[[1, 0, -1]]]).float())
        self.grad_conv.weight.requires_grad = False



    ##你要不要重新写一个GradDepthLoss，你这样改的话，原本用到的GradLoss就会乱
    def forward(self, gtdepth, dtdepth, std, min_std):
        #print(gtdepth.shape)
        #print(dtdepth.shape)
        gtdepth, dtdepth = gtdepth/(std + min_std)**2, dtdepth/(std + min_std)**2
        gt_direction, _, gt_angle_grad = get_all(gtdepth, self.grad_conv)
        dt_direction, _, dt_angle_grad = get_all(dtdepth, self.grad_conv)
        ##print(dt_direction.shape)
        #print(std.shape)
        #print(dt_angle_grad.shape)

        normal_loss = (1 - self.cos(gt_direction, dt_direction)).mean()
        grad_loss = self.loss(gt_angle_grad, dt_angle_grad)#y_est/(std + min_std)**2, y_ref/(std + min_std)**2
        return normal_loss, grad_loss
