"""
@date: 2022/7/16
@description:
"""

from torch.nn import L1Loss
from ..loss.grad_loss import GradLoss
from ..loss.seg_loss import SegLoss
from ..loss.grad_depth_loss import GradDepthLoss
