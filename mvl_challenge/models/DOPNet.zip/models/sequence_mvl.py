from mvl_challenge.models.DOPNet.utils.conversion import depth2xyz,xyz2depth
import torch
import torch
import torch.nn.functional as F

def align_features(features, depths, poses, depth_planes=64):
    b, c, w = features.shape
    device = features.device
    all_volumes = torch.zeros(b, c, w, depth_planes, device=device)
    variance_volumes = torch.zeros(b, c, w, depth_planes, device=device)
    count_volumes = torch.zeros(b, c, w, depth_planes, device=device)

    xyzs = depth2xyz(depths).transpose(1, 2)
    homogenous_xyzs = torch.cat([xyzs, torch.ones(b, 1, w, device=device)], dim=1).float()
    poses = poses.to(torch.float32)
    uni_xyzs = torch.bmm(poses[:, :3, :], homogenous_xyzs)
    uni_xyzs = torch.cat([uni_xyzs, torch.ones(b, 1, w, device=device)], dim=1)

    depth_intervals = torch.linspace(0, 1, depth_planes, device=device)

    for ref_id in range(b):
        ref_pose_inv = poses[ref_id].to(torch.float32).inverse()
        transformed_xyzs = torch.bmm(ref_pose_inv[:3, :].unsqueeze(0).expand(b, -1, -1), uni_xyzs).transpose(1, 2)
        #print(transformed_xyzs.shape)

        # Smooth transition for masks
        depth_diff = transformed_xyzs[..., 2:3] - depth_intervals.view(1, 1, -1)
        #print(depth_diff.shape)
        masks = torch.exp(-depth_diff**2 / (2 * (1/64)**2))  # Use a Gaussian-like soft mask
        #print(masks.shape)
        #print(features.shape)
        
        #masks = masks.squeeze(0).squeeze(0)
        masks = masks.unsqueeze(1)

        expanded_features = features.unsqueeze(3)
        masked_features = expanded_features * masks.float()
        sum_features = masked_features.sum(dim=2, keepdim=True)
        mean_features = sum_features / (masks.sum(dim=2, keepdim=True).float() + 1e-8)
        squared_difference = (masked_features - mean_features) ** 2
        variance = squared_difference.sum(dim=2, keepdim=True) / (masks.sum(dim=2, keepdim=True).float() + 1e-8)

        all_volumes[ref_id] += mean_features.sum(dim=0)
        variance_volumes[ref_id] += variance.sum(dim=0)
        count_volumes[ref_id] += masks.sum(dim=2, keepdim=True).sum(dim=0)

    all_volumes /= (count_volumes + 1e-8)
    variance_volumes /= (count_volumes + 1e-8)

    return all_volumes / b, variance_volumes / b

def extract_best_depth_from_cost_volume(mean_volume, variance_volume):
    #print(variance_volume.shape)
    best_depth_indices = torch.argmin(variance_volume, dim=3)
    #print(best_depth_indices.shape)
    b, c, w, _ = mean_volume.shape
    batch_indices = torch.arange(b)[:, None, None].expand(b, c, w).to(mean_volume.device)
    channel_indices = torch.arange(c)[None, :, None].expand(b, c, w).to(mean_volume.device)
    width_indices = torch.arange(w)[None, None, :].expand(b, c, w).to(mean_volume.device)

    best_depth_features = mean_volume[batch_indices, channel_indices, width_indices, best_depth_indices]

    return best_depth_features

def calculate_costV(features, depths, poses):  
    b, c, w = features.shape
    b, w = depths.shape
    min_vals = depths.min(dim=1, keepdim=True).values
    max_vals = depths.max(dim=1, keepdim=True).values
    normalized_depths = (depths - min_vals) / (max_vals - min_vals)
    mean_volume, variance_volume = align_features(features, normalized_depths, poses)
    best_features = extract_best_depth_from_cost_volume(mean_volume, variance_volume)

    return best_features
